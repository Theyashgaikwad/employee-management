# Employee Management System - Running Instructions

## Project Structure

This microservices project consists of the following services:

1. **discovery-server** - Eureka Service Registry (Port: 8761)
2. **api-gateway** - Spring Cloud Gateway (Port: 8080)
3. **auth-service** - Authentication Service with JWT (Port: 9000)
4. **employee-service** - Employee Management Service (Port: 9001)
5. **department-service** - Department Management Service (Port: 9002)

## Prerequisites

- Java 17+
- Maven 3.8+
- Any IDE (IntelliJ, Eclipse, VSCode)

## Database Configuration

All services use **H2 in-memory database** for simplicity. No additional database setup is required.

## Running the Application

### Step 1: Start the Discovery Server

```bash
cd discovery-server
mvn spring-boot:run
```

- Access Eureka Dashboard: http://localhost:8761

### Step 2: Start the API Gateway

```bash
cd api-gateway
mvn spring-boot:run
```

### Step 3: Start the Auth Service

```bash
cd auth-service
mvn spring-boot:run
```

- Access H2 Console: http://localhost:9000/h2-console
- JDBC URL: `jdbc:h2:mem:authdb`
- Username: `sa`
- Password: `password`

### Step 4: Start the Employee Service

```bash
cd employee-service
mvn spring-boot:run
```

- Access H2 Console: http://localhost:9001/h2-console
- JDBC URL: `jdbc:h2:mem:employeedb`
- Username: `sa`
- Password: `password`

### Step 5: Start the Department Service

```bash
cd department-service
mvn spring-boot:run
```

- Access H2 Console: http://localhost:9002/h2-console
- JDBC URL: `jdbc:h2:mem:departmentdb`
- Username: `sa`
- Password: `password`

## API Endpoints

### Authentication Service (via API Gateway)

- **Register User**: `POST /auth/register`
- **Login User**: `POST /auth/login`
- **Validate Token**: `GET /auth/validate?token={token}`

### Employee Service (via API Gateway)

- **Get All Employees**: `GET /employees`
- **Get Employee by ID**: `GET /employees/{id}`
- **Create Employee**: `POST /employees`
- **Update Employee**: `PUT /employees/{id}`
- **Delete Employee**: `DELETE /employees/{id}`
- **Get Employees by Department**: `GET /employees/department/{department}`

### Department Service (via API Gateway)

- **Get All Departments**: `GET /departments`
- **Get Department by ID**: `GET /departments/{id}`
- **Create Department**: `POST /departments`
- **Update Department**: `PUT /departments/{id}`
- **Delete Department**: `DELETE /departments/{id}`
- **Get Department by Name**: `GET /departments/name/{name}`

## Role-Based Access Control

### Roles:
- **ADMIN**: Full CRUD access to employees, departments, attendance, leave management, and salary management
- **EMPLOYEE**: Can update their own salary, leave requests, and view their information

### Sample User Registration:

**Admin User:**
```json
{
  "username": "admin",
  "password": "admin123",
  "role": "ADMIN"
}
```

**Employee User:**
```json
{
  "username": "employee",
  "password": "emp123",
  "role": "EMPLOYEE"
}
```

## Postman Collection

Import the Postman collection from: `postman/Employee Management System.postman_collection.json`

## Testing the Application

1. Register an admin user
2. Login to get JWT token
3. Use the token in Authorization header for other API calls
4. Test all CRUD operations for employees and departments

## Troubleshooting

- If services don't register with Eureka, check the Eureka server logs
- If API Gateway routes don't work, verify all services are running
- For database issues, check H2 console for each service

## Shutting Down

Simply stop all the running Spring Boot applications (Ctrl+C in each terminal).