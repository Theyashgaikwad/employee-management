# Employee Management System - Microservices Architecture

## Project Structure

This project implements an Employee Management System using Spring Boot microservices with:
- Eureka Server for service discovery
- Spring Security with JWT authentication
- Multiple microservices (Employee, Department, Authentication)
- API Gateway for routing
- Postman collection for testing

## Services

1. **discovery-server**: Eureka service registry
2. **api-gateway**: Spring Cloud Gateway
3. **auth-service**: Authentication service with JWT
4. **employee-service**: Employee management microservice
5. **department-service**: Department management microservice

## Technology Stack

- Spring Boot 3.x
- Spring Cloud
- Spring Security with JWT
- Eureka Server
- Spring Cloud Gateway
- PostgreSQL (for each service)
- Lombok
- Postman for API testing

## How to Run

1. Start the discovery server
2. Start the API gateway
3. Start the auth service
4. Start the employee service
5. Start the department service

All services will automatically register with Eureka.