package com.example.employees.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.employees.entity.Employee;
import com.example.employees.entity.Salary;

@Repository
public interface SalaryRepository extends JpaRepository<Salary, Long> {

    List<Salary> findByEmployee(Employee employee);

    List<Salary> findByEmployeeAndYear(Employee employee, Integer year);

    List<Salary> findByEmployeeAndMonthAndYear(Employee employee, String month, Integer year);
}