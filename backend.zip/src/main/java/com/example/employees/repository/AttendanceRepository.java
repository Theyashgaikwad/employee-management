package com.example.employees.repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.employees.entity.Attendance;
import com.example.employees.entity.Employee;

@Repository
public interface AttendanceRepository extends JpaRepository<Attendance, Long> {

    List<Attendance> findByEmployee(Employee employee);

    List<Attendance> findByEmployeeAndDateBetween(Employee employee, LocalDate startDate, LocalDate endDate);

    List<Attendance> findByDate(LocalDate date);

    @Query("SELECT a FROM Attendance a WHERE a.employee.id = :employeeId AND YEAR(a.date) = :year AND MONTH(a.date) = :month")
    List<Attendance> findByEmployeeAndMonth(@Param("employeeId") Long employeeId, @Param("year") int year, @Param("month") int month);

    @Query("SELECT a FROM Attendance a WHERE a.employee = :employee AND a.date = :date")
    Optional<Attendance> findByEmployeeAndDate(@Param("employee") Employee employee, @Param("date") LocalDate date);

    boolean existsByEmployeeAndDate(Employee employee, LocalDate date);
}