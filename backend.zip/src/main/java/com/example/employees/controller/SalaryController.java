package com.example.employees.controller;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.employees.entity.Employee;
import com.example.employees.entity.Salary;
import com.example.employees.repository.EmployeeRepository;
import com.example.employees.repository.SalaryRepository;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;

@RestController
@RequestMapping("/api/salaries")
@SecurityRequirement(name = "bearerAuth")
public class SalaryController {

    private final SalaryRepository salaryRepository;
    private final EmployeeRepository employeeRepository;

    public SalaryController(SalaryRepository salaryRepository, EmployeeRepository employeeRepository) {
        this.salaryRepository = salaryRepository;
        this.employeeRepository = employeeRepository;
    }

    @GetMapping
    public List<Salary> list() {
        return salaryRepository.findAll();
    }

    @GetMapping("/employee/{employeeId}")
    public List<Salary> getByEmployee(@PathVariable Long employeeId) {
        Optional<Employee> employee = employeeRepository.findById(employeeId);
        return employee.map(salaryRepository::findByEmployee).orElse(List.of());
    }

    @PostMapping
    public ResponseEntity<?> create(@RequestBody Salary salary) {
        if (salary.getEmployee() == null || salary.getEmployee().getId() == null) {
            return ResponseEntity.badRequest().body("Employee is required");
        }

        Optional<Employee> employeeOpt = employeeRepository.findById(salary.getEmployee().getId());
        if (employeeOpt.isEmpty()) {
            return ResponseEntity.badRequest().body("Employee not found");
        }

        salary.setId(null);
        salary.setPayDate(LocalDate.now());

        // Calculate net salary
        double gross = (salary.getBasicSalary() != null ? salary.getBasicSalary() : 0) +
                      (salary.getHra() != null ? salary.getHra() : 0) +
                      (salary.getConveyance() != null ? salary.getConveyance() : 0) +
                      (salary.getMedical() != null ? salary.getMedical() : 0) +
                      (salary.getLta() != null ? salary.getLta() : 0);

        double deductions = (salary.getPf() != null ? salary.getPf() : 0) +
                           (salary.getTax() != null ? salary.getTax() : 0) +
                           (salary.getDeductions() != null ? salary.getDeductions() : 0);

        salary.setNetSalary(gross - deductions);
        salary.setStatus("PENDING");

        Salary saved = salaryRepository.save(salary);
        return ResponseEntity.ok(saved);
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> update(@PathVariable Long id, @RequestBody Salary salary) {
        return salaryRepository.findById(id).map(existing -> {
            existing.setBasicSalary(salary.getBasicSalary());
            existing.setHra(salary.getHra());
            existing.setConveyance(salary.getConveyance());
            existing.setMedical(salary.getMedical());
            existing.setLta(salary.getLta());
            existing.setPf(salary.getPf());
            existing.setGratuity(salary.getGratuity());
            existing.setTax(salary.getTax());
            existing.setDeductions(salary.getDeductions());
            existing.setStatus(salary.getStatus());

            // Recalculate net salary
            double gross = (existing.getBasicSalary() != null ? existing.getBasicSalary() : 0) +
                          (existing.getHra() != null ? existing.getHra() : 0) +
                          (existing.getConveyance() != null ? existing.getConveyance() : 0) +
                          (existing.getMedical() != null ? existing.getMedical() : 0) +
                          (existing.getLta() != null ? existing.getLta() : 0);

            double deductions = (existing.getPf() != null ? existing.getPf() : 0) +
                               (existing.getTax() != null ? existing.getTax() : 0) +
                               (existing.getDeductions() != null ? existing.getDeductions() : 0);

            existing.setNetSalary(gross - deductions);

            salaryRepository.save(existing);
            return ResponseEntity.ok(existing);
        }).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(@PathVariable Long id) {
        if (salaryRepository.existsById(id)) {
            salaryRepository.deleteById(id);
            return ResponseEntity.ok("Salary record deleted successfully");
        }
        return ResponseEntity.notFound().build();
    }
}