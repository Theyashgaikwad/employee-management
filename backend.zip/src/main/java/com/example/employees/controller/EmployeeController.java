package com.example.employees.controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.employees.entity.Employee;
import com.example.employees.repository.EmployeeRepository;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;

@RestController
@RequestMapping("/api/employees")
@SecurityRequirement(name = "bearerAuth")
public class EmployeeController {

    private final EmployeeRepository employeeRepository;

    public EmployeeController(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }

    @GetMapping
    public List<Employee> list() {
        return employeeRepository.findAll();
    }

    @GetMapping("/export")
    public ResponseEntity<byte[]> exportToExcel() throws IOException {
        List<Employee> employees = employeeRepository.findAll();

        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Employees");

        // Create header row
        Row headerRow = sheet.createRow(0);
        headerRow.createCell(0).setCellValue("ID");
        headerRow.createCell(1).setCellValue("First Name");
        headerRow.createCell(2).setCellValue("Last Name");
        headerRow.createCell(3).setCellValue("Email");
        headerRow.createCell(4).setCellValue("Phone");
        headerRow.createCell(5).setCellValue("Address");
        headerRow.createCell(6).setCellValue("Department");
        headerRow.createCell(7).setCellValue("Position");
        headerRow.createCell(8).setCellValue("Salary");

        // Create data rows
        int rowNum = 1;
        for (Employee employee : employees) {
            Row row = sheet.createRow(rowNum++);
            row.createCell(0).setCellValue(employee.getId());
            row.createCell(1).setCellValue(employee.getFirstName());
            row.createCell(2).setCellValue(employee.getLastName());
            row.createCell(3).setCellValue(employee.getEmail());
            row.createCell(4).setCellValue(employee.getPhone() != null ? employee.getPhone() : "");
            row.createCell(5).setCellValue(employee.getAddress() != null ? employee.getAddress() : "");
            row.createCell(6).setCellValue(employee.getDepartment() != null ? employee.getDepartment().getName() : "");
            row.createCell(7).setCellValue(employee.getRole() != null ? employee.getRole().getName() : "");
            row.createCell(8).setCellValue(employee.getSalary() != null ? employee.getSalary() : 0);
        }

        // Auto-size columns
        for (int i = 0; i < 9; i++) {
            sheet.autoSizeColumn(i);
        }

        // Write to byte array
        java.io.ByteArrayOutputStream outputStream = new java.io.ByteArrayOutputStream();
        workbook.write(outputStream);
        workbook.close();

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        headers.setContentDispositionFormData("attachment", "employees.xlsx");

        return ResponseEntity.ok()
                .headers(headers)
                .body(outputStream.toByteArray());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Employee> get(@PathVariable Long id) {
        Optional<Employee> emp = employeeRepository.findById(id);
        return emp.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Employee> create(@RequestBody Employee employee) {
        employee.setId(null);
        Employee saved = employeeRepository.save(employee);
        return ResponseEntity.ok(saved);
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> update(@PathVariable Long id, @RequestBody Employee employee) {
        return employeeRepository.findById(id).map(existing -> {
            existing.setFirstName(employee.getFirstName());
            existing.setLastName(employee.getLastName());
            existing.setEmail(employee.getEmail());
            existing.setPhone(employee.getPhone());
            existing.setAddress(employee.getAddress());
            existing.setPosition(employee.getPosition());
            existing.setDepartment(employee.getDepartment());
            existing.setRole(employee.getRole());
            existing.setSalary(employee.getSalary());
            employeeRepository.save(existing);
            return ResponseEntity.ok(existing);
        }).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(@PathVariable Long id) {
        if (employeeRepository.existsById(id)) {
            employeeRepository.deleteById(id);
            return ResponseEntity.ok("Employee deleted successfully");
        }
        return ResponseEntity.notFound().build();
    }
    
    @DeleteMapping("/name/{firstName}")
    public ResponseEntity<?> deleteByName(@PathVariable String firstName) {
        if (employeeRepository.existsByFirstName(firstName)) {
            employeeRepository.deleteByFirstName(firstName);
            return ResponseEntity.ok("Employee with name '" + firstName + "' deleted successfully");
        }
        return ResponseEntity.status(404).body("Employee not found");
    }

    @PutMapping("/{id}/profile")
    public ResponseEntity<Employee> updateProfile(@PathVariable Long id, @RequestBody Employee profileUpdate) {
        return employeeRepository.findById(id).map(existing -> {
            existing.setFirstName(profileUpdate.getFirstName());
            existing.setLastName(profileUpdate.getLastName());
            existing.setEmail(profileUpdate.getEmail());
            existing.setPhone(profileUpdate.getPhone());
            existing.setAddress(profileUpdate.getAddress());
            existing.setProfilePicture(profileUpdate.getProfilePicture());
            employeeRepository.save(existing);
            return ResponseEntity.ok(existing);
        }).orElseGet(() -> ResponseEntity.notFound().build());
    }


}
