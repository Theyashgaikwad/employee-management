package com.example.employees.controller;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.employees.entity.Attendance;
import com.example.employees.entity.Employee;
import com.example.employees.repository.AttendanceRepository;
import com.example.employees.repository.EmployeeRepository;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;

@RestController
@RequestMapping("/api/attendance")
@SecurityRequirement(name = "bearerAuth")
public class AttendanceController {

    private final AttendanceRepository attendanceRepository;
    private final EmployeeRepository employeeRepository;

    public AttendanceController(AttendanceRepository attendanceRepository, EmployeeRepository employeeRepository) {
        this.attendanceRepository = attendanceRepository;
        this.employeeRepository = employeeRepository;
    }

    @GetMapping
    public List<Attendance> list() {
        return attendanceRepository.findAll();
    }

    @GetMapping("/employee/{employeeId}")
    public List<Attendance> getByEmployee(@PathVariable Long employeeId) {
        Optional<Employee> employee = employeeRepository.findById(employeeId);
        return employee.map(attendanceRepository::findByEmployee).orElse(List.of());
    }

    @GetMapping("/employee/{employeeId}/month")
    public List<Attendance> getByEmployeeAndMonth(@PathVariable Long employeeId,
                                                 @RequestParam int year,
                                                 @RequestParam int month) {
        return attendanceRepository.findByEmployeeAndMonth(employeeId, year, month);
    }

    @PostMapping("/checkin/{employeeId}")
    public ResponseEntity<?> checkIn(@PathVariable Long employeeId) {
        Optional<Employee> employeeOpt = employeeRepository.findById(employeeId);
        if (employeeOpt.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        Employee employee = employeeOpt.get();
        LocalDate today = LocalDate.now();

        if (attendanceRepository.existsByEmployeeAndDate(employee, today)) {
            return ResponseEntity.badRequest().body("Already checked in today");
        }

        Attendance attendance = Attendance.builder()
                .employee(employee)
                .date(today)
                .checkInTime(LocalDateTime.now())
                .status("PRESENT")
                .build();

        Attendance saved = attendanceRepository.save(attendance);
        return ResponseEntity.ok(saved);
    }

    @PutMapping("/checkout/{employeeId}")
    public ResponseEntity<?> checkOut(@PathVariable Long employeeId) {
        Optional<Employee> employeeOpt = employeeRepository.findById(employeeId);
        if (employeeOpt.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        Employee employee = employeeOpt.get();
        LocalDate today = LocalDate.now();

        Optional<Attendance> attendanceOpt = attendanceRepository.findByEmployeeAndDate(employee, today)
                .stream().findFirst();

        if (attendanceOpt.isEmpty()) {
            return ResponseEntity.badRequest().body("No check-in record found for today");
        }

        Attendance attendance = attendanceOpt.get();
        if (attendance.getCheckOutTime() != null) {
            return ResponseEntity.badRequest().body("Already checked out today");
        }

        attendance.setCheckOutTime(LocalDateTime.now());
        if (attendance.getCheckInTime() != null) {
            double hours = java.time.Duration.between(attendance.getCheckInTime(), attendance.getCheckOutTime()).toMinutes() / 60.0;
            attendance.setWorkingHours(hours);
        }

        Attendance saved = attendanceRepository.save(attendance);
        return ResponseEntity.ok(saved);
    }

    @PostMapping
    public ResponseEntity<Attendance> create(@RequestBody Attendance attendance) {
        attendance.setId(null);
        Attendance saved = attendanceRepository.save(attendance);
        return ResponseEntity.ok(saved);
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> update(@PathVariable Long id, @RequestBody Attendance attendance) {
        return attendanceRepository.findById(id).map(existing -> {
            existing.setDate(attendance.getDate());
            existing.setCheckInTime(attendance.getCheckInTime());
            existing.setCheckOutTime(attendance.getCheckOutTime());
            existing.setWorkingHours(attendance.getWorkingHours());
            existing.setStatus(attendance.getStatus());
            existing.setNotes(attendance.getNotes());
            attendanceRepository.save(existing);
            return ResponseEntity.ok(existing);
        }).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(@PathVariable Long id) {
        if (attendanceRepository.existsById(id)) {
            attendanceRepository.deleteById(id);
            return ResponseEntity.ok("Attendance record deleted successfully");
        }
        return ResponseEntity.notFound().build();
    }
}