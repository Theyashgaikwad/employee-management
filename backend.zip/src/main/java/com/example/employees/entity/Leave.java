package com.example.employees.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.time.LocalDate;

@Entity
@Getter
@Setter
@Table(name="leave_request")
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Leave {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "employee_id")
    private Employee employee;

    private LocalDate startDate;
    private LocalDate endDate;
    private String leaveType; // CASUAL, SICK, EARNED, MATERNITY, etc.
    private String reason;
    private String status; // PENDING, APPROVED, REJECTED
    private LocalDate appliedDate;
    private LocalDate approvedDate;

    @ManyToOne
    @JoinColumn(name = "approved_by")
    private Employee approvedBy;

    private String comments;
    private Integer daysCount;
}