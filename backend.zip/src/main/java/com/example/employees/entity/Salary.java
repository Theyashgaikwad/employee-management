package com.example.employees.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.time.LocalDate;

@Entity
@Getter
@Setter
@Table(name="salary")
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Salary {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "employee_id")
    private Employee employee;

    private LocalDate payDate;
    private Double basicSalary;
    private Double hra; // House Rent Allowance
    private Double conveyance;
    private Double medical;
    private Double lta; // Leave Travel Allowance
    private Double pf; // Provident Fund
    private Double gratuity;
    private Double tax;
    private Double deductions;
    private Double netSalary;
    @Column(name = "month_name")
    private String month;
    @Column(name = "salary_year")
    private Integer year;
    private String status; // PAID, PENDING
}