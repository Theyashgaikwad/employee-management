INSERT INTO department (name) VALUES ('Engineering');
INSERT INTO department (name) VALUES ('HR');
INSERT INTO department (name) VALUES ('Finance');

INSERT INTO role (name) VALUES ('Manager');
INSERT INTO role (name) VALUES ('Employee');

INSERT INTO EMPLOYEE (id, first_name, last_name, email, salary, department_id, role_id)
VALUES (1, 'John', 'Doe', 'john.doe@example.com', 60000, 1, 1);
INSERT INTO EMPLOYEE (id, first_name, last_name, email, salary, department_id, role_id)
VALUES (2, 'Jane', 'Smith', 'jane.smith@example.com', 50000, 2, 2);
INSERT INTO EMPLOYEE (id, first_name, last_name, email, salary, department_id, role_id)
VALUES (3, 'Sam', 'Wilson', 'sam.wilson@example.com', 55000, 3, 2);

-- Insert admin user with new structure
INSERT INTO USERS (username, password, email, first_name, last_name, enabled, account_non_expired, account_non_locked, credentials_non_expired) VALUES ('admin',
'$2a$10$DOWSDfB3qJzE1E6FhZf3..G0w1E6jzQy5uZYQZC1x6rT9Yq9qQ6V6', 'admin@example.com', 'Admin', 'User', true, true, true, true);

-- Insert admin roles
INSERT INTO user_roles (user_id, role) VALUES ((SELECT id FROM users WHERE username = 'admin'), 'ROLE_ADMIN');
INSERT INTO user_roles (user_id, role) VALUES ((SELECT id FROM users WHERE username = 'admin'), 'ROLE_USER');
INSERT INTO user_roles (user_id, role) VALUES ((SELECT id FROM users WHERE username = 'admin'), 'ROLE_EMPLOYEE');

-- password for admin above is `admin123` encoded with BCrypt (example)