package com.example.employees.dto;

import lombok.Data;

import java.util.Set;

@Data
public class AuthRequest {
    private String username;
    private String password;
    private String email;
    private String firstName;
    private String lastName;
    private Set<String> roles;
    private String profileImage; // Base64 encoded image or URL
}
