package com.example.employees.controller;

import com.example.employees.entity.User;
import com.example.employees.exception.ResourceNotFoundException;
import com.example.employees.repository.UserRepository;
import com.example.employees.security.JwtUtil;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/user")
public class UserController {

    private final UserRepository userRepository;
    private final JwtUtil jwtUtil;

    public UserController(UserRepository userRepository, JwtUtil jwtUtil) {
        this.userRepository = userRepository;
        this.jwtUtil = jwtUtil;
    }

    @GetMapping("/profile")
    public ResponseEntity<?> getUserProfile() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        Map<String, Object> profile = new HashMap<>();
        profile.put("id", user.getId());
        profile.put("username", user.getUsername());
        profile.put("email", user.getEmail());
        profile.put("firstName", user.getFirstName());
        profile.put("lastName", user.getLastName());
        profile.put("phone", user.getPhone());
        profile.put("address", user.getAddress());
        profile.put("profileImageUrl", user.getProfileImageUrl());
        profile.put("roles", user.getRoles());

        return ResponseEntity.ok(profile);
    }

    @PutMapping("/profile")
    public ResponseEntity<?> updateUserProfile(@RequestBody Map<String, Object> profileUpdate) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        // Update only the fields that are provided
        if (profileUpdate.containsKey("email")) {
            user.setEmail((String) profileUpdate.get("email"));
        }
        if (profileUpdate.containsKey("firstName")) {
            user.setFirstName((String) profileUpdate.get("firstName"));
        }
        if (profileUpdate.containsKey("lastName")) {
            user.setLastName((String) profileUpdate.get("lastName"));
        }
        if (profileUpdate.containsKey("phone")) {
            user.setPhone((String) profileUpdate.get("phone"));
        }
        if (profileUpdate.containsKey("address")) {
            user.setAddress((String) profileUpdate.get("address"));
        }

        userRepository.save(user);

        return ResponseEntity.ok("Profile updated successfully");
    }

    @PutMapping("/change-password")
    public ResponseEntity<?> changePassword(@RequestBody Map<String, String> passwordChange) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        String currentPassword = passwordChange.get("currentPassword");
        String newPassword = passwordChange.get("newPassword");

        // In a real application, you would verify the current password here
        // For simplicity, we'll just update the password

        user.setPassword(newPassword); // In production, you would encode this
        userRepository.save(user);

        return ResponseEntity.ok("Password changed successfully");
    }
}