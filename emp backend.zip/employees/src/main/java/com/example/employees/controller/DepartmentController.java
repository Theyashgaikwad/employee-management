package com.example.employees.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.employees.entity.Department;
import com.example.employees.repository.DepartmentRepository;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;

@RestController
@RequestMapping("/api/departments")
@SecurityRequirement(name = "bearerAuth")
public class DepartmentController {

    private final DepartmentRepository departmentRepository;

    public DepartmentController(DepartmentRepository departmentRepository) {
        this.departmentRepository = departmentRepository;
    }

    @GetMapping
    public List<Department> list() {
        return departmentRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Department> get(@PathVariable Long id) {
        Optional<Department> dept = departmentRepository.findById(id);
        return dept.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<?> create(@RequestBody Department department) {
        if (departmentRepository.existsByName(department.getName())) {
            return ResponseEntity.badRequest().body("Department name already exists");
        }
        department.setId(null);
        Department saved = departmentRepository.save(department);
        return ResponseEntity.ok(saved);
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> update(@PathVariable Long id, @RequestBody Department department) {
        return departmentRepository.findById(id).map(existing -> {
            if (!existing.getName().equals(department.getName()) &&
                departmentRepository.existsByName(department.getName())) {
                return ResponseEntity.badRequest().body("Department name already exists");
            }
            existing.setName(department.getName());
            existing.setDescription(department.getDescription());
            existing.setManager(department.getManager());
            departmentRepository.save(existing);
            return ResponseEntity.ok(existing);
        }).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(@PathVariable Long id) {
        if (departmentRepository.existsById(id)) {
            departmentRepository.deleteById(id);
            return ResponseEntity.ok("Department deleted successfully");
        }
        return ResponseEntity.notFound().build();
    }
}