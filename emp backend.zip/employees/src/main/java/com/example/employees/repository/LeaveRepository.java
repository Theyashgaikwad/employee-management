package com.example.employees.repository;

import java.time.LocalDate;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.employees.entity.Employee;
import com.example.employees.entity.Leave;

@Repository
public interface LeaveRepository extends JpaRepository<Leave, Long> {

    List<Leave> findByEmployee(Employee employee);

    List<Leave> findByStatus(String status);

    List<Leave> findByEmployeeAndStatus(Employee employee, String status);

    @Query("SELECT l FROM Leave l WHERE l.startDate <= :date AND l.endDate >= :date AND l.status = 'APPROVED'")
    List<Leave> findApprovedLeavesOnDate(@Param("date") LocalDate date);

    @Query("SELECT COUNT(l) FROM Leave l WHERE l.employee = :employee AND l.status = 'APPROVED' AND YEAR(l.startDate) = :year")
    long countApprovedLeavesByEmployeeAndYear(@Param("employee") Employee employee, @Param("year") int year);
}