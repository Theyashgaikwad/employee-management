package com.example.employees.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.example.employees.entity.Document;
import com.example.employees.entity.Employee;
import com.example.employees.repository.DocumentRepository;
import com.example.employees.repository.EmployeeRepository;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;

@RestController
@RequestMapping("/api/documents")
@SecurityRequirement(name = "bearerAuth")
public class DocumentController {

    private final DocumentRepository documentRepository;
    private final EmployeeRepository employeeRepository;

    public DocumentController(DocumentRepository documentRepository, EmployeeRepository employeeRepository) {
        this.documentRepository = documentRepository;
        this.employeeRepository = employeeRepository;
    }

    @PostMapping("/upload/{employeeId}")
    public ResponseEntity<?> uploadDocument(@PathVariable Long employeeId,
                                           @RequestParam("file") MultipartFile file,
                                           @RequestParam(value = "expiryDate", required = false) String expiryDateStr) {
        try {
            Employee employee = employeeRepository.findById(employeeId).orElse(null);
            if (employee == null) {
                return ResponseEntity.notFound().build();
            }

            Document document = Document.builder()
                    .fileName(file.getOriginalFilename())
                    .fileType(file.getContentType())
                    .data(file.getBytes())
                    .employee(employee)
                    .uploadDate(LocalDate.now())
                    .expiryDate(expiryDateStr != null ? LocalDate.parse(expiryDateStr) : null)
                    .build();

            Document saved = documentRepository.save(document);
            return ResponseEntity.ok(saved);
        } catch (IOException e) {
            return ResponseEntity.badRequest().body("Failed to upload file: " + e.getMessage());
        }
    }

    @GetMapping("/employee/{employeeId}")
    public List<Document> getDocumentsByEmployee(@PathVariable Long employeeId) {
        return documentRepository.findByEmployeeId(employeeId);
    }

    @GetMapping("/download/{id}")
    public ResponseEntity<byte[]> downloadDocument(@PathVariable Long id) {
        Document document = documentRepository.findById(id).orElse(null);
        if (document == null) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(document.getFileType()))
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + document.getFileName() + "\"")
                .body(document.getData());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteDocument(@PathVariable Long id) {
        if (documentRepository.existsById(id)) {
            documentRepository.deleteById(id);
            return ResponseEntity.ok("Document deleted successfully");
        }
        return ResponseEntity.notFound().build();
    }
}