package com.example.employees.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/stats")
@PreAuthorize("hasAnyRole('EMPLOYEE', 'ADMIN')")
public class StatisticsController {

    @GetMapping("/departments/stats")
    public ResponseEntity<List<Map<String, Object>>> getDepartmentStats() {
        List<Map<String, Object>> stats = Arrays.asList(
            Map.of(
                "name", "Engineering",
                "employeeCount", 15,
                "averageSalary", 85000
            ),
            Map.of(
                "name", "Marketing",
                "employeeCount", 8,
                "averageSalary", 72000
            ),
            Map.of(
                "name", "HR",
                "employeeCount", 5,
                "averageSalary", 68000
            ),
            Map.of(
                "name", "Finance",
                "employeeCount", 7,
                "averageSalary", 78000
            )
        );
        return ResponseEntity.ok(stats);
    }

    @GetMapping("/employees/salary-distribution")
    public ResponseEntity<List<Map<String, Object>>> getSalaryDistribution() {
        List<Map<String, Object>> distribution = Arrays.asList(
            Map.of("range", "0-50K", "count", 3),
            Map.of("range", "50K-75K", "count", 8),
            Map.of("range", "75K-100K", "count", 12),
            Map.of("range", "100K+", "count", 7)
        );
        return ResponseEntity.ok(distribution);
    }

    @GetMapping("/performance/stats")
    public ResponseEntity<List<Map<String, Object>>> getPerformanceStats() {
        List<Map<String, Object>> performance = Arrays.asList(
            Map.of("rating", "Excellent", "count", 8),
            Map.of("rating", "Good", "count", 12),
            Map.of("rating", "Average", "count", 7),
            Map.of("rating", "Needs Improvement", "count", 3)
        );
        return ResponseEntity.ok(performance);
    }

    @GetMapping("/attendance/stats")
    public ResponseEntity<Map<String, Object>> getAttendanceStats() {
        Map<String, Object> stats = Map.of(
            "present", 25,
            "absent", 3,
            "late", 2
        );
        return ResponseEntity.ok(stats);
    }

    @GetMapping("/employees/monthly-growth")
    public ResponseEntity<List<Map<String, Object>>> getMonthlyGrowth() {
        List<Map<String, Object>> growth = Arrays.asList(
            Map.of("month", "Jan", "count", 2),
            Map.of("month", "Feb", "count", 3),
            Map.of("month", "Mar", "count", 5),
            Map.of("month", "Apr", "count", 4),
            Map.of("month", "May", "count", 6),
            Map.of("month", "Jun", "count", 7),
            Map.of("month", "Jul", "count", 8),
            Map.of("month", "Aug", "count", 9),
            Map.of("month", "Sep", "count", 10),
            Map.of("month", "Oct", "count", 12),
            Map.of("month", "Nov", "count", 15),
            Map.of("month", "Dec", "count", 18)
        );
        return ResponseEntity.ok(growth);
    }
}