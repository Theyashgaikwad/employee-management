package com.example.employees.controller;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Optional;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.employees.entity.Employee;
import com.example.employees.entity.Leave;
import com.example.employees.repository.EmployeeRepository;
import com.example.employees.repository.LeaveRepository;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;

@RestController
@RequestMapping("/api/leaves")
@SecurityRequirement(name = "bearerAuth")
public class LeaveController {

    private final LeaveRepository leaveRepository;
    private final EmployeeRepository employeeRepository;

    public LeaveController(LeaveRepository leaveRepository, EmployeeRepository employeeRepository) {
        this.leaveRepository = leaveRepository;
        this.employeeRepository = employeeRepository;
    }

    @GetMapping
    public List<Leave> list() {
        return leaveRepository.findAll();
    }

    @GetMapping("/employee/{employeeId}")
    public List<Leave> getByEmployee(@PathVariable Long employeeId) {
        Optional<Employee> employee = employeeRepository.findById(employeeId);
        return employee.map(leaveRepository::findByEmployee).orElse(List.of());
    }

    @GetMapping("/status/{status}")
    public List<Leave> getByStatus(@PathVariable String status) {
        return leaveRepository.findByStatus(status.toUpperCase());
    }

    @PostMapping
    public ResponseEntity<?> create(@RequestBody Leave leave) {
        if (leave.getEmployee() == null || leave.getEmployee().getId() == null) {
            return ResponseEntity.badRequest().body("Employee is required");
        }

        Optional<Employee> employeeOpt = employeeRepository.findById(leave.getEmployee().getId());
        if (employeeOpt.isEmpty()) {
            return ResponseEntity.badRequest().body("Employee not found");
        }

        leave.setId(null);
        leave.setAppliedDate(LocalDate.now());
        leave.setStatus("PENDING");

        // Calculate days count
        if (leave.getStartDate() != null && leave.getEndDate() != null) {
            long days = ChronoUnit.DAYS.between(leave.getStartDate(), leave.getEndDate()) + 1;
            leave.setDaysCount((int) days);
        }

        Leave saved = leaveRepository.save(leave);
        return ResponseEntity.ok(saved);
    }

    @PutMapping("/{id}/approve")
    public ResponseEntity<?> approve(@PathVariable Long id, @RequestParam Long approvedById) {
        Optional<Employee> approverOpt = employeeRepository.findById(approvedById);
        if (approverOpt.isEmpty()) {
            return ResponseEntity.badRequest().body("Approver not found");
        }

        return leaveRepository.findById(id).map(leave -> {
            leave.setStatus("APPROVED");
            leave.setApprovedDate(LocalDate.now());
            leave.setApprovedBy(approverOpt.get());
            leaveRepository.save(leave);
            return ResponseEntity.ok(leave);
        }).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}/reject")
    public ResponseEntity<?> reject(@PathVariable Long id, @RequestParam Long approvedById,
                                   @RequestParam String comments) {
        Optional<Employee> approverOpt = employeeRepository.findById(approvedById);
        if (approverOpt.isEmpty()) {
            return ResponseEntity.badRequest().body("Approver not found");
        }

        return leaveRepository.findById(id).map(leave -> {
            leave.setStatus("REJECTED");
            leave.setApprovedDate(LocalDate.now());
            leave.setApprovedBy(approverOpt.get());
            leave.setComments(comments);
            leaveRepository.save(leave);
            return ResponseEntity.ok(leave);
        }).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> update(@PathVariable Long id, @RequestBody Leave leave) {
        return leaveRepository.findById(id).map(existing -> {
            existing.setStartDate(leave.getStartDate());
            existing.setEndDate(leave.getEndDate());
            existing.setLeaveType(leave.getLeaveType());
            existing.setReason(leave.getReason());
            existing.setComments(leave.getComments());

            // Recalculate days count
            if (leave.getStartDate() != null && leave.getEndDate() != null) {
                long days = ChronoUnit.DAYS.between(leave.getStartDate(), leave.getEndDate()) + 1;
                existing.setDaysCount((int) days);
            }

            leaveRepository.save(existing);
            return ResponseEntity.ok(existing);
        }).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(@PathVariable Long id) {
        if (leaveRepository.existsById(id)) {
            leaveRepository.deleteById(id);
            return ResponseEntity.ok("Leave request deleted successfully");
        }
        return ResponseEntity.notFound().build();
    }

    @GetMapping("/employee/{employeeId}/balance")
    public ResponseEntity<?> getLeaveBalance(@PathVariable Long employeeId) {
        Optional<Employee> employeeOpt = employeeRepository.findById(employeeId);
        if (employeeOpt.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        int currentYear = LocalDate.now().getYear();
        long usedLeaves = leaveRepository.countApprovedLeavesByEmployeeAndYear(employeeOpt.get(), currentYear);

        // Assuming 20 days annual leave
        int totalLeaves = 20;
        int remainingLeaves = totalLeaves - (int) usedLeaves;

        return ResponseEntity.ok(new LeaveBalance(totalLeaves, (int) usedLeaves, remainingLeaves));
    }

    public static class LeaveBalance {
        public int total;
        public int used;
        public int remaining;

        public LeaveBalance(int total, int used, int remaining) {
            this.total = total;
            this.used = used;
            this.remaining = remaining;
        }
    }
}