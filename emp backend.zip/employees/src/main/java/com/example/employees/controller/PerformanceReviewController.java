package com.example.employees.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.employees.entity.Employee;
import com.example.employees.entity.PerformanceReview;
import com.example.employees.repository.EmployeeRepository;
import com.example.employees.repository.PerformanceReviewRepository;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;

@RestController
@RequestMapping("/api/performance-reviews")
@SecurityRequirement(name = "bearerAuth")
public class PerformanceReviewController {

    private final PerformanceReviewRepository performanceReviewRepository;
    private final EmployeeRepository employeeRepository;

    public PerformanceReviewController(PerformanceReviewRepository performanceReviewRepository,
                                     EmployeeRepository employeeRepository) {
        this.performanceReviewRepository = performanceReviewRepository;
        this.employeeRepository = employeeRepository;
    }

    @GetMapping("/employee/{employeeId}")
    public List<PerformanceReview> getReviewsByEmployee(@PathVariable Long employeeId) {
        return performanceReviewRepository.findByEmployeeIdOrderByReviewDateDesc(employeeId);
    }

    @PostMapping
    public ResponseEntity<PerformanceReview> createReview(@RequestBody PerformanceReview review) {
        review.setReviewDate(LocalDate.now());
        PerformanceReview saved = performanceReviewRepository.save(review);
        return ResponseEntity.ok(saved);
    }

    @PutMapping("/{id}")
    public ResponseEntity<PerformanceReview> updateReview(@PathVariable Long id, @RequestBody PerformanceReview review) {
        return performanceReviewRepository.findById(id).map(existing -> {
            existing.setQuarter(review.getQuarter());
            existing.setRating(review.getRating());
            existing.setManagerFeedback(review.getManagerFeedback());
            existing.setEmployeeSelfAssessment(review.getEmployeeSelfAssessment());
            existing.setGoals(review.getGoals());
            existing.setAchievements(review.getAchievements());
            PerformanceReview saved = performanceReviewRepository.save(existing);
            return ResponseEntity.ok(saved);
        }).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteReview(@PathVariable Long id) {
        if (performanceReviewRepository.existsById(id)) {
            performanceReviewRepository.deleteById(id);
            return ResponseEntity.ok("Performance review deleted successfully");
        }
        return ResponseEntity.notFound().build();
    }
}