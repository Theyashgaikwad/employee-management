import { Injectable } from '@angular/core';
import { ToastrService } from 'ngx-toastr';

export type ToastType = 'success' | 'error' | 'info' | 'warning';

@Injectable({
  providedIn: 'root'
})
export class ToastService {
  constructor(private toastr: ToastrService) {}

  show(message: string, title?: string, type: ToastType = 'info', options: any = {}): void {
    const defaultOptions = {
      timeOut: 5000,
      positionClass: 'toast-top-right',
      closeButton: true,
      progressBar: true,
      ...options
    };

    switch (type) {
      case 'success':
        this.toastr.success(message, title, defaultOptions);
        break;
      case 'error':
        this.toastr.error(message, title, defaultOptions);
        break;
      case 'info':
        this.toastr.info(message, title, defaultOptions);
        break;
      case 'warning':
        this.toastr.warning(message, title, defaultOptions);
        break;
      default:
        this.toastr.show(message, title, defaultOptions);
    }
  }

  success(message: string, title: string = 'Success'): void {
    this.show(message, title, 'success');
  }

  error(message: string, title: string = 'Error'): void {
    this.show(message, title, 'error');
  }

  info(message: string, title: string = 'Info'): void {
    this.show(message, title, 'info');
  }

  warning(message: string, title: string = 'Warning'): void {
    this.show(message, title, 'warning');
  }
}