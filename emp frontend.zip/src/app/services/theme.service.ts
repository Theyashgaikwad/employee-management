import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ThemeService {
  private readonly THEME_KEY = 'theme';
  private readonly DARK_THEME = 'dark';
  private readonly LIGHT_THEME = 'light';

  constructor() {
    this.initializeTheme();
  }

  private initializeTheme(): void {
    const savedTheme = localStorage.getItem(this.THEME_KEY);
    if (savedTheme) {
      this.applyTheme(savedTheme);
    } else {
      // Default to light theme
      this.applyTheme(this.LIGHT_THEME);
    }
  }

  private applyTheme(theme: string): void {
    document.documentElement.classList.remove(this.DARK_THEME, this.LIGHT_THEME);
    document.documentElement.classList.add(theme);
    localStorage.setItem(this.THEME_KEY, theme);
  }

  toggleTheme(): void {
    const currentTheme = this.getCurrentTheme();
    const newTheme = currentTheme === this.DARK_THEME ? this.LIGHT_THEME : this.DARK_THEME;
    this.applyTheme(newTheme);
  }

  getCurrentTheme(): string {
    return localStorage.getItem(this.THEME_KEY) || this.LIGHT_THEME;
  }

  isDarkTheme(): boolean {
    return this.getCurrentTheme() === this.DARK_THEME;
  }
}