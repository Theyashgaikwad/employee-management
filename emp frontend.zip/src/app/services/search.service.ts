import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { delay } from 'rxjs/operators';

export interface SearchResult {
  id: string;
  title: string;
  type: 'employee' | 'department' | 'role' | 'menu';
  description?: string;
  icon?: string;
  route?: string;
}

@Injectable({
  providedIn: 'root'
})
export class SearchService {
  private mockData: SearchResult[] = [
    // Employees
    { id: 'emp1', title: 'John Doe', type: 'employee', description: 'Software Engineer', icon: 'person', route: '/employees/1' },
    { id: 'emp2', title: 'Jane Smith', type: 'employee', description: 'HR Manager', icon: 'person', route: '/employees/2' },
    { id: 'emp3', title: 'Mike Johnson', type: 'employee', description: 'Product Manager', icon: 'person', route: '/employees/3' },
    { id: 'emp4', title: 'Sarah Williams', type: 'employee', description: 'UX Designer', icon: 'person', route: '/employees/4' },
    { id: 'emp5', title: 'David Brown', type: 'employee', description: 'DevOps Engineer', icon: 'person', route: '/employees/5' },

    // Departments
    { id: 'dept1', title: 'Engineering', type: 'department', description: 'Software Development', icon: 'code', route: '/departments/1' },
    { id: 'dept2', title: 'Human Resources', type: 'department', description: 'HR Management', icon: 'people', route: '/departments/2' },
    { id: 'dept3', title: 'Marketing', type: 'department', description: 'Brand & Growth', icon: 'campaign', route: '/departments/3' },
    { id: 'dept4', title: 'Finance', type: 'department', description: 'Financial Operations', icon: 'attach_money', route: '/departments/4' },

    // Roles
    { id: 'role1', title: 'Admin', type: 'role', description: 'Administrator access', icon: 'admin_panel_settings', route: '/roles/1' },
    { id: 'role2', title: 'Manager', type: 'role', description: 'Management access', icon: 'supervisor_account', route: '/roles/2' },
    { id: 'role3', title: 'Employee', type: 'role', description: 'Standard employee access', icon: 'person', route: '/roles/3' },
    { id: 'role4', title: 'HR', type: 'role', description: 'Human Resources access', icon: 'group', route: '/roles/4' },

    // Menu items
    { id: 'menu1', title: 'Dashboard', type: 'menu', description: 'Main dashboard', icon: 'dashboard', route: '/dashboard' },
    { id: 'menu2', title: 'Employees', type: 'menu', description: 'Employee management', icon: 'people', route: '/employees' },
    { id: 'menu3', title: 'Departments', type: 'menu', description: 'Department management', icon: 'business', route: '/departments' },
    { id: 'menu4', title: 'Roles', type: 'menu', description: 'Role management', icon: 'admin_panel_settings', route: '/roles' },
    { id: 'menu5', title: 'Attendance', type: 'menu', description: 'Attendance tracking', icon: 'calendar_today', route: '/attendance' },
    { id: 'menu6', title: 'Leaves', type: 'menu', description: 'Leave management', icon: 'event', route: '/leaves' },
    { id: 'menu7', title: 'Salaries', type: 'menu', description: 'Salary management', icon: 'attach_money', route: '/salaries' },
    { id: 'menu8', title: 'Profile', type: 'menu', description: 'User profile', icon: 'person', route: '/profile' }
  ];

  search(query: string): Observable<SearchResult[]> {
    if (!query || query.trim() === '') {
      return of([]);
    }

    const lowerQuery = query.toLowerCase();
    const results = this.mockData.filter(item =>
      item.title.toLowerCase().includes(lowerQuery) ||
      (item.description && item.description.toLowerCase().includes(lowerQuery))
    );

    // Add some delay to simulate API call
    return of(results).pipe(delay(300));
  }

  getSearchTypes(): string[] {
    return ['employee', 'department', 'role', 'menu'];
  }
}