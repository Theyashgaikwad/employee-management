import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AuthService } from './auth.service';

export interface DepartmentStats {
  name: string;
  employeeCount: number;
  averageSalary: number;
}

export interface SalaryRangeStats {
  range: string;
  count: number;
}

export interface PerformanceStats {
  rating: string;
  count: number;
}

export interface ChartData {
  labels: string[];
  datasets: {
    label: string;
    data: number[];
    backgroundColor: string[];
    borderColor: string[];
    borderWidth: number;
  }[];
}

@Injectable({
  providedIn: 'root'
})
export class StatisticsService {
  private apiUrl = '/api';

  constructor(
    private http: HttpClient,
    private authService: AuthService
  ) {}

  private getHeaders(): HttpHeaders {
    const token = this.authService.getToken();
    return new HttpHeaders({
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    });
  }

  // Get department statistics
  getDepartmentStats(): Observable<DepartmentStats[]> {
    return this.http.get<DepartmentStats[]>(`${this.apiUrl}/stats/departments/stats`, { headers: this.getHeaders() });
  }

  // Get salary distribution statistics
  getSalaryDistribution(): Observable<SalaryRangeStats[]> {
    return this.http.get<SalaryRangeStats[]>(`${this.apiUrl}/stats/employees/salary-distribution`, { headers: this.getHeaders() });
  }

  // Get performance statistics
  getPerformanceStats(): Observable<PerformanceStats[]> {
    return this.http.get<PerformanceStats[]>(`${this.apiUrl}/stats/performance/stats`, { headers: this.getHeaders() });
  }

  // Get attendance statistics
  getAttendanceStats(): Observable<{ present: number; absent: number; late: number }> {
    return this.http.get<{ present: number; absent: number; late: number }>(`${this.apiUrl}/stats/attendance/stats`, { headers: this.getHeaders() });
  }

  // Get monthly employee growth
  getMonthlyGrowth(): Observable<{ month: string; count: number }[]> {
    return this.http.get<{ month: string; count: number }[]>(`${this.apiUrl}/stats/employees/monthly-growth`, { headers: this.getHeaders() });
  }

  // Generate chart data for department distribution
  getDepartmentChartData(): Observable<ChartData> {
    return new Observable<ChartData>(observer => {
      this.getDepartmentStats().subscribe({
        next: (stats) => {
          const labels = stats.map(dept => dept.name);
          const data = stats.map(dept => dept.employeeCount);
          const backgroundColors = this.generateColors(stats.length);

          observer.next({
            labels: labels,
            datasets: [{
              label: 'Employees by Department',
              data: data,
              backgroundColor: backgroundColors,
              borderColor: backgroundColors.map(color => this.darkenColor(color, 20)),
              borderWidth: 1
            }]
          });
          observer.complete();
        },
        error: (error) => {
          observer.error(error);
        }
      });
    });
  }

  // Generate chart data for salary distribution
  getSalaryChartData(): Observable<ChartData> {
    return new Observable<ChartData>(observer => {
      this.getSalaryDistribution().subscribe({
        next: (stats) => {
          const labels = stats.map(range => range.range);
          const data = stats.map(range => range.count);
          const backgroundColors = this.generateColors(stats.length);

          observer.next({
            labels: labels,
            datasets: [{
              label: 'Salary Distribution',
              data: data,
              backgroundColor: backgroundColors,
              borderColor: backgroundColors.map(color => this.darkenColor(color, 20)),
              borderWidth: 1
            }]
          });
          observer.complete();
        },
        error: (error) => {
          observer.error(error);
        }
      });
    });
  }

  // Generate chart data for performance distribution
  getPerformanceChartData(): Observable<ChartData> {
    return new Observable<ChartData>(observer => {
      this.getPerformanceStats().subscribe({
        next: (stats) => {
          const labels = stats.map(perf => perf.rating);
          const data = stats.map(perf => perf.count);
          const backgroundColors = this.generateColors(stats.length);

          observer.next({
            labels: labels,
            datasets: [{
              label: 'Performance Ratings',
              data: data,
              backgroundColor: backgroundColors,
              borderColor: backgroundColors.map(color => this.darkenColor(color, 20)),
              borderWidth: 1
            }]
          });
          observer.complete();
        },
        error: (error) => {
          observer.error(error);
        }
      });
    });
  }

  // Generate chart data for attendance
  getAttendanceChartData(): Observable<ChartData> {
    return new Observable<ChartData>(observer => {
      this.getAttendanceStats().subscribe({
        next: (stats) => {
          const labels = ['Present', 'Absent', 'Late'];
          const data = [stats.present, stats.absent, stats.late];
          const backgroundColors = ['#10B981', '#EF4444', '#F59E0B'];

          observer.next({
            labels: labels,
            datasets: [{
              label: 'Attendance Status',
              data: data,
              backgroundColor: backgroundColors,
              borderColor: backgroundColors.map(color => this.darkenColor(color, 20)),
              borderWidth: 1
            }]
          });
          observer.complete();
        },
        error: (error) => {
          observer.error(error);
        }
      });
    });
  }

  // Generate chart data for monthly growth
  getMonthlyGrowthChartData(): Observable<ChartData> {
    return new Observable<ChartData>(observer => {
      this.getMonthlyGrowth().subscribe({
        next: (stats) => {
          const labels = stats.map(item => item.month);
          const data = stats.map(item => item.count);

          observer.next({
            labels: labels,
            datasets: [{
              label: 'Employee Growth',
              data: data,
              backgroundColor: ['rgba(59, 130, 246, 0.2)'],
              borderColor: ['rgba(59, 130, 246, 1)'],
              borderWidth: 2
            }]
          });
          observer.complete();
        },
        error: (error) => {
          observer.error(error);
        }
      });
    });
  }

  // Helper method to generate colors
  private generateColors(count: number): string[] {
    const colors = [
      '#3B82F6', '#10B981', '#EF4444', '#F59E0B',
      '#8B5CF6', '#EC4899', '#06B6D4', '#84CC16'
    ];
    return colors.slice(0, count);
  }

  // Helper method to darken colors
  private darkenColor(color: string, percent: number): string {
    // Simple color darkening logic
    return color.replace(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*\d+\.?\d*)?\)/, (match, r, g, b) => {
      const num = parseInt;
      const R = num(r);
      const G = num(g);
      const B = num(b);
      return `rgb(${Math.round(R * (100 - percent) / 100)},${Math.round(G * (100 - percent) / 100)},${Math.round(B * (100 - percent) / 100)})`;
    });
  }
}