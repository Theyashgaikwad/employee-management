import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface AuthRequest {
  username: string;
  password: string;
  email?: string;
  firstName?: string;
  lastName?: string;
  roles?: string[];
  profileImage?: string;
}

export interface AuthResponse {
  token: string;
}

export interface UserProfile {
  id?: number;
  username: string;
  email?: string;
  firstName?: string;
  lastName?: string;
  phone?: string;
  address?: string;
  profileImageUrl?: string;
  roles?: string[];
}

export interface UserProfileDisplay {
  name: string;
  role: string;
  avatar: string;
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private apiUrl = '/api/auth';
  private userApiUrl = '/api/user';

  constructor(private http: HttpClient) {}

  private getHeaders(): HttpHeaders {
    const token = this.getToken();
    return new HttpHeaders({
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    });
  }

  register(credentials: AuthRequest): Observable<any> {
    return this.http.post(`${this.apiUrl}/register`, credentials);
  }

  login(credentials: AuthRequest): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(`${this.apiUrl}/login`, credentials);
  }

  getUserProfile(): Observable<UserProfile> {
    return this.http.get<UserProfile>(`${this.userApiUrl}/profile`, { headers: this.getHeaders() });
  }

  updateUserProfile(profile: UserProfile): Observable<any> {
    return this.http.put(`${this.userApiUrl}/profile`, profile, { headers: this.getHeaders() });
  }

  changePassword(currentPassword: string, newPassword: string): Observable<any> {
    return this.http.put(`${this.userApiUrl}/change-password`, {
      currentPassword,
      newPassword
    }, { headers: this.getHeaders() });
  }

  setToken(token: string): void {
    localStorage.setItem('token', token);
  }

  getToken(): string | null {
    return localStorage.getItem('token');
  }

  isAuthenticated(): boolean {
    return !!this.getToken();
  }

  logout(): void {
    localStorage.removeItem('token');
  }
}
