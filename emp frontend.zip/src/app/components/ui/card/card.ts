import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

export type CardVariant = 'default' | 'glass' | 'bordered' | 'elevated';

@Component({
  selector: 'ui-card',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './card.html',
  styleUrl: './card.css'
})
export class UiCard {
  @Input() variant: CardVariant = 'default';
  @Input() title: string = '';
  @Input() subtitle: string = '';
  @Input() headerActions: boolean = false;
  @Input() footer: boolean = false;
  @Input() loading: boolean = false;
  @Input() hoverable: boolean = false;

  get cardClasses(): string {
    return `
      ui-card
      ui-card--${this.variant}
      ${this.hoverable ? 'ui-card--hoverable' : ''}
      ${this.loading ? 'ui-card--loading' : ''}
    `;
  }
}