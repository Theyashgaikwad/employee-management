import { Component, inject, OnInit, OnDestroy } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { EmployeeService, Employee } from '../../services/employee.service';
import { StatisticsService } from '../../services/statistics.service';
import { ToastService } from '../../services/toast.service';
import { CommonModule } from '@angular/common';
import { ChartsComponent } from '../charts/charts';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink, ChartsComponent],
  templateUrl: './dashboard.html',
  styleUrl: './dashboard.css'
})
export class Dashboard implements OnInit {
  authService = inject(AuthService);
  employeeService = inject(EmployeeService);
  router = inject(Router);
  toastService = inject(ToastService);

  employees: Employee[] = [];
  loading = false;
  errorMessage = '';

  // Dashboard statistics
  stats = {
    totalEmployees: 0,
    newEmployees: 0,
    maleEmployees: 0,
    femaleEmployees: 0,
    activeEmployees: 0,
    onLeave: 0
  };

  // Chart data
  performanceData = {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
    datasets: [
      {
        label: 'Work Performance',
        data: [65, 59, 80, 81, 56, 55, 40, 75, 60, 85, 90, 70],
        borderColor: '#3B82F6',
        backgroundColor: 'rgba(59, 130, 246, 0.1)',
        tension: 0.4,
        fill: true
      }
    ]
  };

  attendanceData = {
    value: 85,
    max: 100,
    label: 'Attendance Rate'
  };

  ngOnInit(): void {
    this.loadDashboardData();

    // Set up periodic refresh for real-time updates
    this.setupRealTimeUpdates();
  }

  loadDashboardData(): void {
    this.loading = true;
    this.employeeService.getEmployees().subscribe({
      next: (data) => {
        this.employees = data;
        this.calculateStats();
        this.loading = false;
      },
      error: (error) => {
        console.error('Error loading employees:', error);
        this.errorMessage = 'Failed to load dashboard data';
        this.loading = false;
      }
    });
  }

  calculateStats(): void {
    this.stats.totalEmployees = this.employees.length;
    this.stats.newEmployees = Math.floor(Math.random() * 10) + 1;
    this.stats.maleEmployees = Math.floor(this.employees.length * 0.6);
    this.stats.femaleEmployees = this.employees.length - this.stats.maleEmployees;
    this.stats.activeEmployees = Math.floor(this.employees.length * 0.85);
    this.stats.onLeave = this.employees.length - this.stats.activeEmployees;
  }

  calculateMalePercentage(): number {
    return this.stats.totalEmployees > 0
      ? Math.round((this.stats.maleEmployees / this.stats.totalEmployees) * 100)
      : 0;
  }

  calculateFemalePercentage(): number {
    return this.stats.totalEmployees > 0
      ? Math.round((this.stats.femaleEmployees / this.stats.totalEmployees) * 100)
      : 0;
  }

  logout(): void {
    this.authService.logout();
    this.router.navigate(['/login']);
  }

  // Chart options
  chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      y: {
        beginAtZero: true,
        grid: {
          color: 'rgba(255, 255, 255, 0.1)'
        },
        ticks: {
          color: '#9CA3AF'
        }
      },
      x: {
        grid: {
          color: 'rgba(255, 255, 255, 0.1)'
        },
        ticks: {
          color: '#9CA3AF'
        }
      }
    },
    plugins: {
      legend: {
        labels: {
          color: '#FFFFFF'
        }
      }
    }
  };

  gaugeOptions = {
    responsive: true,
    maintainAspectRatio: false,
    circumference: 180,
    rotation: -90,
    cutout: '80%',
    plugins: {
      legend: {
        display: false
      },
      tooltip: {
        enabled: true
      }
    }
  };

  deleteEmployee(id: number | undefined): void {
    if (!id) return;

    if (confirm('Are you sure you want to delete this employee?')) {
      this.employeeService.deleteEmployee(id).subscribe({
        next: () => {
          this.loadDashboardData();
        },
        error: (error) => {
          console.error('Error deleting employee:', error);
          this.errorMessage = 'Failed to delete employee';
        }
      });
    }
  }

  // Real-time updates setup
  private setupRealTimeUpdates(): void {
    // Refresh employee data every 30 seconds for real-time updates
    const refreshInterval = 30000; // 30 seconds

    // Set up periodic refresh
    setInterval(() => {
      console.log('Refreshing employee data for real-time updates...');
      this.loadDashboardData();
    }, refreshInterval);

    // Also set up event listener for employee creation events
    this.setupEmployeeCreationListener();
  }

  private setupEmployeeCreationListener(): void {
    // Listen for employee creation events (could be implemented via WebSocket or polling)
    // For now, we'll use a simple polling mechanism
    const pollingInterval = 10000; // 10 seconds

    setInterval(() => {
      this.checkForNewEmployees();
    }, pollingInterval);
  }

  private checkForNewEmployees(): void {
    // Get current employee count
    const currentCount = this.employees.length;

    // Fetch latest employee data
    this.employeeService.getEmployees().subscribe({
      next: (latestEmployees) => {
        // If new employees were added, update the list
        if (latestEmployees.length > currentCount) {
          console.log(`New employees detected! Refreshing from ${currentCount} to ${latestEmployees.length} employees`);
          this.employees = latestEmployees;
          this.calculateStats();
          this.toastService.success('New employees added! Dashboard updated.', 'Real-time Update');
        }
      },
      error: (error) => {
        console.error('Error checking for new employees:', error);
      }
    });
  }
}
