import { Component, inject, OnInit } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { ToastService } from '../../services/toast.service';
import { ThemeService } from '../../services/theme.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-home',
  imports: [CommonModule, RouterLink],
  templateUrl: './home.html',
  styleUrl: './home.css',
})
export class Home implements OnInit {
  authService = inject(AuthService);
  toastService = inject(ToastService);
  router = inject(Router);
  themeService = inject(ThemeService);

  userRole: string = 'Loading...';
  userProfile: any = null;
  stats = {
    totalEmployees: 0,
    employeeChange: 0,
    activeUsers: 0,
    userChange: 0,
    departments: 0,
    departmentChange: 0
  };

  ngOnInit(): void {
    this.loadUserProfile();
    this.loadStats();
  }

  loadUserProfile(): void {
    this.authService.getUserProfile().subscribe({
      next: (profile) => {
        this.userProfile = profile;
        this.userRole = profile.roles?.join(', ') || 'User';
        this.toastService.success(`Welcome back, ${profile.firstName || profile.username}!`, 'Welcome');
      },
      error: (error) => {
        console.error('Error loading user profile:', error);
        this.userRole = 'User';
        this.toastService.error('Failed to load user profile', 'Error');
      }
    });
  }

  loadStats(): void {
    // In a real application, you would fetch this from an API
    // For demo purposes, we'll use mock data
    setTimeout(() => {
      this.stats = {
        totalEmployees: 42,
        employeeChange: 12,
        activeUsers: 35,
        userChange: 8,
        departments: 7,
        departmentChange: 2
      };
    }, 1000);
  }

  logout(): void {
    this.authService.logout();
    this.toastService.info('You have been logged out', 'Logout');
    this.router.navigate(['/login']);
  }

  toggleTheme(): void {
    this.themeService.toggleTheme();
  }

  isDarkTheme(): boolean {
    return this.themeService.isDarkTheme();
  }
}