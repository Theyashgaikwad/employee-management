import { Component, inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { ToastService } from '../../services/toast.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-register',
  imports: [ReactiveFormsModule, CommonModule, RouterLink],
  templateUrl: './register.html',
  styleUrl: './register.css',
})
export class Register {
  fb = inject(FormBuilder);
  authService = inject(AuthService);
  toastService = inject(ToastService);
  router = inject(Router);

  registerForm: FormGroup;
  loading = false;
  errorMessage = '';
  successMessage = '';
  profileImagePreview: string | null = null;
  profileImageFile: File | null = null;

  constructor() {
    this.registerForm = this.fb.group({
      username: ['', [Validators.required, Validators.minLength(3)]],
      email: ['', [Validators.required, Validators.email]],
      firstName: ['', []],
      lastName: ['', []],
      password: ['', [Validators.required, Validators.minLength(6)]],
      confirmPassword: ['', [Validators.required]],
      role: ['ROLE_USER', [Validators.required]]
    }, { validators: this.passwordMatchValidator });
  }

  passwordMatchValidator(group: FormGroup): { [key: string]: boolean } | null {
    const password = group.get('password')?.value;
    const confirmPassword = group.get('confirmPassword')?.value;
    return password === confirmPassword ? null : { passwordMismatch: true };
  }

  onProfileImageChange(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
      this.profileImageFile = input.files[0];

      // Create preview
      const reader = new FileReader();
      reader.onload = (e: any) => {
        this.profileImagePreview = e.target.result;
      };
      reader.readAsDataURL(input.files[0]);
    }
  }

  onSubmit(): void {
    if (this.registerForm.invalid) {
      return;
    }

    this.loading = true;
    this.errorMessage = '';
    this.successMessage = '';

    const { username, password, email, firstName, lastName, role } = this.registerForm.value;

    // Handle profile image upload asynchronously
    if (this.profileImageFile) {
      const reader = new FileReader();
      reader.readAsDataURL(this.profileImageFile);
      reader.onload = () => {
        const profileImageBase64 = reader.result as string;

        this.authService.register({
          username,
          password,
          email,
          firstName,
          lastName,
          roles: [role],
          profileImage: profileImageBase64
        }).subscribe(this.handleRegistrationResponse());
      };
      reader.onerror = () => {
        // If image reading fails, proceed without image
        this.authService.register({
          username,
          password,
          email,
          firstName,
          lastName,
          roles: [role]
        }).subscribe(this.handleRegistrationResponse());
      };
    } else {
      // No profile image, proceed with registration
      this.authService.register({
        username,
        password,
        email,
        firstName,
        lastName,
        roles: [role]
      }).subscribe(this.handleRegistrationResponse());
    }
  }

  private handleRegistrationResponse() {
    return {
      next: (response: any) => {
        this.loading = false;
        this.successMessage = 'Registration successful! Redirecting to login...';
        this.toastService.success('Registration successful! Redirecting to login...', 'Success');
        setTimeout(() => {
          this.router.navigate(['/login']);
        }, 2000);
      },
      error: (error: any) => {
        this.loading = false;
        const errorMessage = error.error?.message || error.error || 'Registration failed. Please try again.';
        this.errorMessage = errorMessage;
        this.toastService.error(errorMessage, 'Registration Error');
      }
    };
  }
}
