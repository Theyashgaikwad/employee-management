import { Component, inject, HostListener } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AuthService, UserProfile, UserProfileDisplay } from '../../services/auth.service';
import { ThemeService } from '../../services/theme.service';
import { SearchService, SearchResult } from '../../services/search.service';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule],
  templateUrl: './navbar.html',
  styleUrl: './navbar.css'
})
export class Navbar {
  authService = inject(AuthService);
  themeService = inject(ThemeService);
  searchService = inject(SearchService);
  router = inject(Router);

  userProfile: UserProfileDisplay = {
    name: 'John Doe',
    role: 'Admin',
    avatar: 'https://i.pravatar.cc/40?u=john'
  };

  notifications = [
    { id: 1, message: 'New employee added', time: '2h ago', read: false },
    { id: 2, message: 'Attendance report generated', time: '5h ago', read: true },
    { id: 3, message: 'System update available', time: '1d ago', read: false }
  ];

  showProfileDropdown = false;
  showNotificationsDropdown = false;
  showSearchResults = false;
  searchQuery = '';
  searchResults: SearchResult[] = [];
  isSearching = false;

  constructor() {
    this.loadUserProfile();
  }

  loadUserProfile(): void {
    this.authService.getUserProfile().subscribe({
      next: (profile) => {
        this.userProfile = {
          name: profile.firstName + ' ' + profile.lastName,
          role: profile.roles?.join(', ') || 'User',
          avatar: profile.profileImageUrl || 'https://i.pravatar.cc/40?u=' + profile.username
        };
      },
      error: () => {
        // Fallback to default profile
        this.userProfile = {
          name: 'John Doe',
          role: 'Admin',
          avatar: 'https://i.pravatar.cc/40?u=john'
        };
      }
    });
  }

  toggleTheme(): void {
    this.themeService.toggleTheme();
  }

  logout(): void {
    this.authService.logout();
    this.router.navigate(['/login']);
  }

  markAllAsRead(): void {
    this.notifications = this.notifications.map(n => ({ ...n, read: true }));
  }

  hasUnreadNotifications(): boolean {
    return this.notifications.some(n => !n.read);
  }

  toggleProfileDropdown(): void {
    this.showProfileDropdown = !this.showProfileDropdown;
    // Close other dropdowns if open
    this.showNotificationsDropdown = false;
    this.showSearchResults = false;
  }

  toggleNotificationsDropdown(): void {
    this.showNotificationsDropdown = !this.showNotificationsDropdown;
    // Close other dropdowns if open
    this.showProfileDropdown = false;
    this.showSearchResults = false;
  }

  onSearchInput(): void {
    if (this.searchQuery.length > 0) {
      this.isSearching = true;
      this.searchService.search(this.searchQuery).subscribe({
        next: (results) => {
          this.searchResults = results;
          this.showSearchResults = results.length > 0;
          this.isSearching = false;
        },
        error: () => {
          this.searchResults = [];
          this.showSearchResults = false;
          this.isSearching = false;
        }
      });
    } else {
      this.searchResults = [];
      this.showSearchResults = false;
    }
  }

  clearSearch(): void {
    this.searchQuery = '';
    this.searchResults = [];
    this.showSearchResults = false;
  }

  navigateToResult(result: SearchResult): void {
    this.searchQuery = '';
    this.showSearchResults = false;
    if (result.route) {
      this.router.navigate([result.route]);
    }
  }

  getIconForType(type: string): string {
    const icons: Record<string, string> = {
      'employee': 'person',
      'department': 'business',
      'role': 'admin_panel_settings',
      'menu': 'menu'
    };
    return icons[type] || 'search';
  }

  // Close dropdowns when clicking outside
  @HostListener('document:click', ['$event'])
  closeDropdowns(event: MouseEvent): void {
    const target = event.target as HTMLElement;
    if (!target.closest('.relative') && !target.closest('button') && !target.closest('.search-container')) {
      this.showProfileDropdown = false;
      this.showNotificationsDropdown = false;
      // Don't close search results when clicking inside search
      if (!target.closest('.search-results')) {
        this.showSearchResults = false;
      }
    }
  }
}