import { Component, Input, OnInit, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
import { Chart, ChartConfiguration, ChartType } from 'chart.js/auto';
import { StatisticsService } from '../../services/statistics.service';
import { CommonModule } from '@angular/common';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-charts',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './charts.html',
  styleUrl: './charts.css'
})
export class ChartsComponent implements OnInit, AfterViewInit {
  @ViewChild('departmentChart') departmentChartRef!: ElementRef<HTMLCanvasElement>;
  @ViewChild('salaryChart') salaryChartRef!: ElementRef<HTMLCanvasElement>;
  @ViewChild('performanceChart') performanceChartRef!: ElementRef<HTMLCanvasElement>;
  @ViewChild('attendanceChart') attendanceChartRef!: ElementRef<HTMLCanvasElement>;
  @ViewChild('growthChart') growthChartRef!: ElementRef<HTMLCanvasElement>;

  private departmentChart: Chart | undefined;
  private salaryChart: Chart | undefined;
  private performanceChart: Chart | undefined;
  private attendanceChart: Chart | undefined;
  private growthChart: Chart | undefined;

  loading = true;
  errorMessage = '';

  constructor(private statisticsService: StatisticsService) {}

  ngOnInit(): void {
    this.loadChartData();
  }

  ngAfterViewInit(): void {
    // Ensure charts are properly initialized after view is ready
    setTimeout(() => {
      if (this.loading) {
        this.loadChartData();
      }
    }, 100);
  }

  loadChartData(): void {
    this.loading = true;
    this.errorMessage = '';

    // Track how many charts have completed loading
    let chartsLoaded = 0;
    const totalCharts = 5;

    // Use mock data directly for development/demo purposes
    console.log('Loading charts with enhanced mock data...');
    this.createDepartmentChart(this.getMockDepartmentData());
    this.checkAllChartsLoaded(++chartsLoaded, totalCharts);

    this.createSalaryChart(this.getMockSalaryData());
    this.checkAllChartsLoaded(++chartsLoaded, totalCharts);

    this.createPerformanceChart(this.getMockPerformanceData());
    this.checkAllChartsLoaded(++chartsLoaded, totalCharts);

    this.createAttendanceChart(this.getMockAttendanceData());
    this.checkAllChartsLoaded(++chartsLoaded, totalCharts);

    this.createGrowthChart(this.getMockGrowthData());
    this.checkAllChartsLoaded(++chartsLoaded, totalCharts);

    // Commented out API calls to ensure mock data is always used
    /*
    this.loadChartWithFallback(
      () => this.statisticsService.getDepartmentChartData(),
      (data) => {
        this.createDepartmentChart(data);
        this.checkAllChartsLoaded(++chartsLoaded, totalCharts);
      },
      'department'
    );

    this.loadChartWithFallback(
      () => this.statisticsService.getSalaryChartData(),
      (data) => {
        this.createSalaryChart(data);
        this.checkAllChartsLoaded(++chartsLoaded, totalCharts);
      },
      'salary'
    );

    this.loadChartWithFallback(
      () => this.statisticsService.getPerformanceChartData(),
      (data) => {
        this.createPerformanceChart(data);
        this.checkAllChartsLoaded(++chartsLoaded, totalCharts);
      },
      'performance'
    );

    this.loadChartWithFallback(
      () => this.statisticsService.getAttendanceChartData(),
      (data) => {
        this.createAttendanceChart(data);
        this.checkAllChartsLoaded(++chartsLoaded, totalCharts);
      },
      'attendance'
    );

    this.loadChartWithFallback(
      () => this.statisticsService.getMonthlyGrowthChartData(),
      (data) => {
        this.createGrowthChart(data);
        this.checkAllChartsLoaded(++chartsLoaded, totalCharts);
      },
      'growth'
    );
    */
  }

  private loadChartWithFallback(
    apiCall: () => Observable<any>,
    successCallback: (data: any) => void,
    chartType: string
  ): void {
    apiCall().subscribe({
      next: (data) => successCallback(data),
      error: (error) => {
        console.warn(`API call failed for ${chartType}, using mock data`, error);
        // Use mock data as fallback
        this.useMockDataForChart(chartType, successCallback);
      }
    });
  }

  private useMockDataForChart(chartType: string, callback: (data: any) => void): void {
    switch (chartType) {
      case 'department':
        callback(this.getMockDepartmentData());
        break;
      case 'salary':
        callback(this.getMockSalaryData());
        break;
      case 'performance':
        callback(this.getMockPerformanceData());
        break;
      case 'attendance':
        callback(this.getMockAttendanceData());
        break;
      case 'growth':
        callback(this.getMockGrowthData());
        break;
    }
  }

  private getMockDepartmentData(): any {
    return {
      labels: ['Engineering', 'Marketing', 'HR', 'Finance', 'Sales', 'Operations'],
      datasets: [{
        label: 'Employees by Department',
        data: [28, 15, 8, 12, 18, 6],
        backgroundColor: [
          'rgba(59, 130, 246, 0.8)',
          'rgba(16, 185, 129, 0.8)',
          'rgba(239, 68, 68, 0.8)',
          'rgba(245, 158, 11, 0.8)',
          'rgba(139, 92, 246, 0.8)',
          'rgba(236, 72, 153, 0.8)'
        ],
        borderColor: [
          'rgba(59, 130, 246, 1)',
          'rgba(16, 185, 129, 1)',
          'rgba(239, 68, 68, 1)',
          'rgba(245, 158, 11, 1)',
          'rgba(139, 92, 246, 1)',
          'rgba(236, 72, 153, 1)'
        ],
        borderWidth: 2,
        borderRadius: 8
      }]
    };
  }

  private getMockSalaryData(): any {
    return {
      labels: ['$30K-$50K', '$50K-$70K', '$70K-$90K', '$90K-$120K', '$120K+'],
      datasets: [{
        label: 'Salary Distribution',
        data: [12, 18, 25, 15, 8],
        backgroundColor: [
          'rgba(239, 68, 68, 0.8)',
          'rgba(245, 158, 11, 0.8)',
          'rgba(16, 185, 129, 0.8)',
          'rgba(59, 130, 246, 0.8)',
          'rgba(139, 92, 246, 0.8)'
        ],
        borderColor: [
          'rgba(239, 68, 68, 1)',
          'rgba(245, 158, 11, 1)',
          'rgba(16, 185, 129, 1)',
          'rgba(59, 130, 246, 1)',
          'rgba(139, 92, 246, 1)'
        ],
        borderWidth: 2,
        borderRadius: 8
      }]
    };
  }

  private getMockPerformanceData(): any {
    return {
      labels: ['Outstanding', 'Exceeds Expectations', 'Meets Expectations', 'Needs Improvement', 'Unsatisfactory'],
      datasets: [{
        label: 'Performance Ratings Distribution',
        data: [12, 18, 25, 10, 5],
        backgroundColor: [
          'rgba(16, 185, 129, 0.8)',
          'rgba(59, 130, 246, 0.8)',
          'rgba(245, 158, 11, 0.8)',
          'rgba(245, 158, 11, 0.6)',
          'rgba(239, 68, 68, 0.8)'
        ],
        borderColor: [
          'rgba(16, 185, 129, 1)',
          'rgba(59, 130, 246, 1)',
          'rgba(245, 158, 11, 1)',
          'rgba(245, 158, 11, 1)',
          'rgba(239, 68, 68, 1)'
        ],
        borderWidth: 2,
        borderRadius: 8
      }]
    };
  }

  private getMockAttendanceData(): any {
    return {
      labels: ['Present', 'Absent', 'Late', 'On Leave'],
      datasets: [{
        label: 'Attendance Status',
        data: [45, 3, 2, 5],
        backgroundColor: [
          'rgba(16, 185, 129, 0.8)',
          'rgba(239, 68, 68, 0.8)',
          'rgba(245, 158, 11, 0.8)',
          'rgba(139, 92, 246, 0.8)'
        ],
        borderColor: [
          'rgba(16, 185, 129, 1)',
          'rgba(239, 68, 68, 1)',
          'rgba(245, 158, 11, 1)',
          'rgba(139, 92, 246, 1)'
        ],
        borderWidth: 2,
        borderRadius: 8
      }]
    };
  }

  private getMockGrowthData(): any {
    return {
      labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
      datasets: [{
        label: 'Employee Growth (2024)',
        data: [15, 18, 22, 20, 25, 28, 30, 32, 35, 38, 42, 45],
        backgroundColor: 'rgba(59, 130, 246, 0.2)',
        borderColor: 'rgba(59, 130, 246, 1)',
        borderWidth: 3,
        tension: 0.4,
        fill: true,
        pointBackgroundColor: 'rgba(59, 130, 246, 1)',
        pointBorderColor: '#fff',
        pointBorderWidth: 2,
        pointRadius: 5,
        pointHoverRadius: 7
      }]
    };
  }

  private createDepartmentChart(data: any): void {
    if (this.departmentChartRef && this.departmentChartRef.nativeElement) {
      const ctx = this.departmentChartRef.nativeElement.getContext('2d');
      if (ctx) {
        if (this.departmentChart) {
          this.departmentChart.destroy();
        }

        const config: ChartConfiguration = {
          type: 'bar',
          data: data,
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
              legend: {
                labels: {
                  color: '#FFFFFF',
                  font: {
                    size: 12
                  }
                }
              },
              title: {
                display: true,
                text: 'Employees by Department',
                color: '#FFFFFF',
                font: {
                  size: 16
                }
              }
            },
            scales: {
              y: {
                beginAtZero: true,
                grid: {
                  color: 'rgba(255, 255, 255, 0.1)'
                },
                ticks: {
                  color: '#9CA3AF',
                  font: {
                    size: 11
                  }
                }
              },
              x: {
                grid: {
                  color: 'rgba(255, 255, 255, 0.1)'
                },
                ticks: {
                  color: '#9CA3AF',
                  font: {
                    size: 11
                  }
                }
              }
            }
          }
        };

        this.departmentChart = new Chart(ctx, config);
      }
    }
  }

  private createSalaryChart(data: any): void {
    if (this.salaryChartRef && this.salaryChartRef.nativeElement) {
      const ctx = this.salaryChartRef.nativeElement.getContext('2d');
      if (ctx) {
        if (this.salaryChart) {
          this.salaryChart.destroy();
        }

        const config: ChartConfiguration = {
          type: 'doughnut',
          data: data,
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
              legend: {
                position: 'right',
                labels: {
                  color: '#FFFFFF',
                  font: {
                    size: 12
                  },
                  padding: 15
                }
              },
              title: {
                display: true,
                text: 'Salary Distribution',
                color: '#FFFFFF',
                font: {
                  size: 16
                }
              }
            }
          }
        };

        this.salaryChart = new Chart(ctx, config);
      }
    }
  }

  private createPerformanceChart(data: any): void {
    if (this.performanceChartRef && this.performanceChartRef.nativeElement) {
      const ctx = this.performanceChartRef.nativeElement.getContext('2d');
      if (ctx) {
        if (this.performanceChart) {
          this.performanceChart.destroy();
        }

        const config: ChartConfiguration = {
          type: 'pie',
          data: data,
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
              legend: {
                position: 'bottom',
                labels: {
                  color: '#FFFFFF',
                  font: {
                    size: 12
                  },
                  padding: 15
                }
              },
              title: {
                display: true,
                text: 'Performance Ratings',
                color: '#FFFFFF',
                font: {
                  size: 16
                }
              }
            }
          }
        };

        this.performanceChart = new Chart(ctx, config);
      }
    }
  }

  private createAttendanceChart(data: any): void {
    if (this.attendanceChartRef && this.attendanceChartRef.nativeElement) {
      const ctx = this.attendanceChartRef.nativeElement.getContext('2d');
      if (ctx) {
        if (this.attendanceChart) {
          this.attendanceChart.destroy();
        }

        const config: ChartConfiguration = {
          type: 'doughnut',
          data: data,
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
              legend: {
                position: 'right',
                labels: {
                  color: '#FFFFFF',
                  font: {
                    size: 12
                  },
                  padding: 15
                }
              },
              title: {
                display: true,
                text: 'Attendance Status',
                color: '#FFFFFF',
                font: {
                  size: 16
                }
              }
            }
          }
        };

        this.attendanceChart = new Chart(ctx, config);
      }
    }
  }

  private createGrowthChart(data: any): void {
    if (this.growthChartRef && this.growthChartRef.nativeElement) {
      const ctx = this.growthChartRef.nativeElement.getContext('2d');
      if (ctx) {
        if (this.growthChart) {
          this.growthChart.destroy();
        }

        const config: ChartConfiguration = {
          type: 'line',
          data: data,
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
              legend: {
                labels: {
                  color: '#FFFFFF',
                  font: {
                    size: 12
                  }
                }
              },
              title: {
                display: true,
                text: 'Monthly Employee Growth',
                color: '#FFFFFF',
                font: {
                  size: 16
                }
              }
            },
            scales: {
              y: {
                beginAtZero: true,
                grid: {
                  color: 'rgba(255, 255, 255, 0.1)'
                },
                ticks: {
                  color: '#9CA3AF',
                  font: {
                    size: 11
                  }
                }
              },
              x: {
                grid: {
                  color: 'rgba(255, 255, 255, 0.1)'
                },
                ticks: {
                  color: '#9CA3AF',
                  font: {
                    size: 11
                  }
                }
              }
            }
          }
        };

        this.growthChart = new Chart(ctx, config);
        this.loading = false;
      }
    }
  }

  private checkAllChartsLoaded(loadedCount: number, totalCharts: number): void {
    if (loadedCount === totalCharts) {
      this.loading = false;
    }
  }

  private handleError(error: any, chartType: string): void {
    console.error(`Error loading ${chartType} chart data:`, error);
    this.errorMessage = `Failed to load ${chartType} chart data`;
    this.loading = false;
  }

  ngOnDestroy(): void {
    // Clean up charts when component is destroyed
    if (this.departmentChart) this.departmentChart.destroy();
    if (this.salaryChart) this.salaryChart.destroy();
    if (this.performanceChart) this.performanceChart.destroy();
    if (this.attendanceChart) this.attendanceChart.destroy();
    if (this.growthChart) this.growthChart.destroy();
  }
}