import { Component, inject, OnInit } from '@angular/core';
import { Router, RouterLink, RouterLinkActive } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AuthService, UserProfile } from '../../services/auth.service';

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive],
  templateUrl: './sidebar.html',
  styleUrl: './sidebar.css'
})
export class Sidebar implements OnInit {
  authService = inject(AuthService);
  router = inject(Router);

  userProfile: UserProfile | null = null;
  isCollapsed = false;
  showThemeToggle = false;

  // Role-based menu items
  adminMenuItems = [
    { icon: 'dashboard', label: 'Dashboard', route: '/dashboard', roles: ['ADMIN', 'MANAGER', 'EMPLOYEE'] },
    { icon: 'employee', label: 'Employees', route: '/employees', roles: ['ADMIN', 'MANAGER'] },
    { icon: 'business', label: 'Departments', route: '/departments', roles: ['ADMIN', 'MANAGER'] },
    { icon: 'admin_panel_settings', label: 'Roles', route: '/roles', roles: ['ADMIN'] },
    { icon: 'attach_money', label: 'Salary', route: '/salaries', roles: ['ADMIN', 'MANAGER'] },
    { icon: 'calendar_today', label: 'Attendance', route: '/attendance', roles: ['ADMIN', 'MANAGER', 'EMPLOYEE'] },
    { icon: 'event', label: 'Leaves', route: '/leaves', roles: ['ADMIN', 'MANAGER', 'EMPLOYEE'] },
    { icon: 'person', label: 'Profile', route: '/profile', roles: ['ADMIN', 'MANAGER', 'EMPLOYEE'] },
    { icon: 'settings', label: 'Settings', route: '/settings', roles: ['ADMIN'] }
  ];

  employeeMenuItems = [
    { icon: 'dashboard', label: 'Dashboard', route: '/dashboard', roles: ['EMPLOYEE', 'ADMIN', 'MANAGER'] },
    { icon: 'calendar_today', label: 'Attendance', route: '/attendance', roles: ['EMPLOYEE', 'ADMIN', 'MANAGER'] },
    { icon: 'event', label: 'Leaves', route: '/leaves', roles: ['EMPLOYEE', 'ADMIN', 'MANAGER'] },
    { icon: 'attach_money', label: 'Salary', route: '/salaries', roles: ['EMPLOYEE', 'ADMIN', 'MANAGER'] },
    { icon: 'person', label: 'Profile', route: '/profile', roles: ['EMPLOYEE', 'ADMIN', 'MANAGER'] }
  ];

  userMenuItems = [
    { icon: 'dashboard', label: 'Dashboard', route: '/dashboard', roles: ['USER', 'ADMIN', 'MANAGER', 'EMPLOYEE'] },
    { icon: 'person', label: 'Profile', route: '/profile', roles: ['USER', 'ADMIN', 'MANAGER', 'EMPLOYEE'] }
  ];

  bottomItems = [
    { icon: 'help', label: 'Help Center', route: '/help', roles: ['ADMIN', 'MANAGER', 'EMPLOYEE', 'USER'] },
    { icon: 'feedback', label: 'Feedback', route: '/feedback', roles: ['ADMIN', 'MANAGER', 'EMPLOYEE', 'USER'] },
    { icon: 'settings', label: 'Settings', route: '/settings', roles: ['ADMIN', 'MANAGER', 'EMPLOYEE', 'USER'] }
  ];

  visibleMenuItems: any[] = [];
  visibleBottomItems: any[] = [];

  ngOnInit(): void {
    this.loadUserProfile();
  }

  loadUserProfile(): void {
    this.authService.getUserProfile().subscribe({
      next: (profile) => {
        this.userProfile = profile;
        this.updateMenuItems();
      },
      error: () => {
        // Fallback to default menu items
        this.updateMenuItems();
      }
    });
  }

  updateMenuItems(): void {
    const userRoles = this.userProfile?.roles || ['USER'];

    // Debug: Log user roles to console
    console.log('User roles:', userRoles);

    // Ensure EMPLOYEE role is properly handled
    const hasEmployeeRole = userRoles.includes('EMPLOYEE') || userRoles.includes('EMPLOYEE_ROLE');
    // Ensure ADMIN role is properly handled
    const hasAdminRole = userRoles.includes('ADMIN') || userRoles.includes('ADMIN_ROLE');

    // Determine which menu set to use based on user roles
    if (hasAdminRole) {
      // For admins, show all admin menu items without filtering
      // to ensure all admin functionality is visible
      this.visibleMenuItems = this.adminMenuItems;
    } else if (hasEmployeeRole) {
      // For employees, show all employee menu items without filtering
      // to ensure all required items are visible
      this.visibleMenuItems = this.employeeMenuItems;
    } else {
      this.visibleMenuItems = this.userMenuItems.filter(item =>
        item.roles.some(role => userRoles.includes(role))
      );
    }

    // Ensure we always have some menu items visible (fallback)
    if (this.visibleMenuItems.length === 0) {
      this.visibleMenuItems = [
        { icon: 'dashboard', label: 'Dashboard', route: '/dashboard', roles: ['USER'] },
        { icon: 'person', label: 'Profile', route: '/profile', roles: ['USER'] }
      ];
    }

    // Filter bottom items based on roles
    this.visibleBottomItems = this.bottomItems.filter(item =>
      item.roles.some(role => userRoles.includes(role))
    );

    // Debug: Log final menu items
    console.log('Visible menu items:', this.visibleMenuItems);
  }

  toggleSidebar(): void {
    this.isCollapsed = !this.isCollapsed;
  }

  toggleThemeToggle(): void {
    this.showThemeToggle = !this.showThemeToggle;
  }

  logout(): void {
    this.authService.logout();
    this.router.navigate(['/login']);
  }
}