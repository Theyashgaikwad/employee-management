import { Component, inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule, FormsModule } from '@angular/forms';
import { Router, ActivatedRoute, RouterLink } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { EmployeeService, Employee } from '../../services/employee.service';
import { DepartmentService, Department } from '../../services/department.service';
import { RoleService, Role } from '../../services/role.service';
import { ToastService } from '../../services/toast.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-employee-form',
  imports: [ReactiveFormsModule, FormsModule, CommonModule, RouterLink],
  templateUrl: './employee-form.html',
  styleUrl: './employee-form.css',
})
export class EmployeeForm implements OnInit {
  fb = inject(FormBuilder);
  authService = inject(AuthService);
  employeeService = inject(EmployeeService);
  departmentService = inject(DepartmentService);
  roleService = inject(RoleService);
  toastService = inject(ToastService);
  router = inject(Router);
  route = inject(ActivatedRoute);

  employeeForm: FormGroup;
  loading = false;
  errorMessage = '';
  isEditMode = false;
  employeeId: number | null = null;
  employee: any = {};

  departments: Department[] = [];
  roles: Role[] = [];

  constructor() {
    this.employeeForm = this.fb.group({
      firstName: ['', [Validators.required, Validators.minLength(2)]],
      lastName: ['', [Validators.required, Validators.minLength(2)]],
      email: ['', [Validators.required, Validators.email]],
      department: [null, [Validators.required]],
      role: [null, [Validators.required]],
      salary: ['', [Validators.required, Validators.min(0)]]
    });
  }

  ngOnInit(): void {
    this.loadDepartments();
    this.loadRoles();

    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.isEditMode = true;
      this.employeeId = Number(id);
      this.loadEmployee(this.employeeId);
    }
  }

  loadDepartments(): void {
    this.departmentService.getDepartments().subscribe({
      next: (departments) => {
        this.departments = departments;
      },
      error: (error) => {
        console.error('Error loading departments:', error);
      }
    });
  }

  loadRoles(): void {
    this.roleService.getRoles().subscribe({
      next: (roles) => {
        this.roles = roles;
      },
      error: (error) => {
        console.error('Error loading roles:', error);
      }
    });
  }

  loadEmployee(id: number): void {
    this.loading = true;
    this.employeeService.getEmployee(id).subscribe({
      next: (employee) => {
        // Ensure all form fields are properly populated
        this.employeeForm.patchValue({
          firstName: employee.firstName || '',
          lastName: employee.lastName || '',
          email: employee.email || '',
          phone: employee.phone || '',
          address: employee.address || '',
          salary: employee.salary || 0,
          department: employee.department?.id || null,
          role: employee.role?.id || null
        });

        this.toastService.success(`Employee ${employee.firstName} ${employee.lastName} loaded for editing`, 'Edit Mode');
        this.loading = false;
      },
      error: (error) => {
        console.error('Error loading employee:', error);
        const errorMsg = error.error?.message || 'Failed to load employee data';
        this.errorMessage = errorMsg;
        this.toastService.error(errorMsg, 'Load Error');
        this.loading = false;
      }
    });
  }

  onSubmit(): void {
    if (this.employeeForm.invalid) {
      this.toastService.error('Please fill in all required fields correctly.');
      return;
    }

    this.loading = true;
    this.errorMessage = '';

    // Transform form data to match backend expectations
    const formData = this.employeeForm.value;

    // Find the selected department and role objects
    const selectedDepartment = this.departments.find(dept => dept.id === formData.department);
    const selectedRole = this.roles.find(role => role.id === formData.role);

    if (!selectedDepartment || !selectedRole) {
      this.loading = false;
      this.toastService.error('Please select valid department and role');
      return;
    }

    // Create proper department and role objects with required fields
    const departmentData = {
      id: selectedDepartment.id || 0,
      name: selectedDepartment.name,
      description: selectedDepartment.description || '',
      manager: selectedDepartment.manager || ''
    };

    const roleData = {
      id: selectedRole.id || 0,
      name: selectedRole.name,
      description: selectedRole.description || '',
      baseSalary: selectedRole.baseSalary || 0
    };

    const employeeData: Employee = {
      firstName: formData.firstName,
      lastName: formData.lastName,
      email: formData.email,
      phone: formData.phone,
      address: formData.address,
      position: formData.position,
      salary: formData.salary,
      // Use properly structured department and role objects
      department: departmentData,
      role: roleData
    };

    // For new employees, ensure no ID is sent
    if (!this.isEditMode) {
      delete employeeData.id;
    }

    const request = this.isEditMode && this.employeeId
      ? this.employeeService.updateEmployee(this.employeeId, employeeData)
      : this.employeeService.createEmployee(employeeData);

    request.subscribe({
      next: (response) => {
        this.loading = false;
        const successMessage = this.isEditMode
          ? `Employee ${response.firstName} ${response.lastName} updated successfully!`
          : `Employee ${response.firstName} ${response.lastName} added successfully!`;

        this.toastService.success(successMessage, 'Success');
        this.router.navigate(['/employees']);
      },
      error: (error) => {
        this.loading = false;
        const errorMessage = error.error?.message || 'Failed to save employee. Please try again.';
        this.errorMessage = errorMessage;
        this.toastService.error(errorMessage, 'Error');
      }
    });
  }

  logout(): void {
    this.authService.logout();
    this.router.navigate(['/login']);
  }

  cancel(): void {
    this.router.navigate(['/employees']);
  }
}
