import { Routes } from '@angular/router';
import { Login } from './components/login/login';
import { Register } from './components/register/register';
import { Dashboard } from './components/dashboard/dashboard';
import { Home } from './components/home/home';
import { Employees } from './components/employees/employees';
import { EmployeeForm } from './components/employee-form/employee-form';
import { Departments } from './components/departments/departments';
import { DepartmentForm } from './components/department-form/department-form';
import { Roles } from './components/roles/roles';
import { RoleForm } from './components/role-form/role-form';
import { Attendance } from './components/attendance/attendance';
import { AttendanceForm } from './components/attendance-form/attendance-form';
import { Leaves } from './components/leaves/leaves';
import { LeaveForm } from './components/leave-form/leave-form';
import { Salaries } from './components/salaries/salaries';
import { SalaryForm } from './components/salary-form/salary-form';
import { DocumentsComponent } from './components/documents/documents';
import { PerformanceReviewsComponent } from './components/performance-reviews/performance-reviews';
import { ProfileComponent } from './components/profile/profile';
import { authGuard } from './guards/auth.guard';
import { Layout } from './components/layout/layout';

export const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'login', component: Login },
  { path: 'register', component: Register },
  {
    path: '',
    component: Layout,
    canActivate: [authGuard],
    children: [
      { path: 'home', component: Home },
      { path: 'dashboard', component: Dashboard },
      { path: 'employees', component: Employees },
      { path: 'employees/add', component: EmployeeForm },
      { path: 'employees/edit/:id', component: EmployeeForm },
      { path: 'departments', component: Departments },
      { path: 'departments/add', component: DepartmentForm },
      { path: 'departments/edit/:id', component: DepartmentForm },
      { path: 'roles', component: Roles },
      { path: 'roles/add', component: RoleForm },
      { path: 'roles/edit/:id', component: RoleForm },
      { path: 'attendance', component: Attendance },
      { path: 'attendance/add', component: AttendanceForm },
      { path: 'attendance/edit/:id', component: AttendanceForm },
      { path: 'leaves', component: Leaves },
      { path: 'leaves/add', component: LeaveForm },
      { path: 'leaves/edit/:id', component: LeaveForm },
      { path: 'salaries', component: Salaries },
      { path: 'salaries/add', component: SalaryForm },
      { path: 'salaries/edit/:id', component: SalaryForm },
      { path: 'employees/:employeeId/documents', component: DocumentsComponent },
      { path: 'employees/:employeeId/performance', component: PerformanceReviewsComponent },
      { path: 'profile', component: ProfileComponent },
      { path: 'schedule', component: Home }, // Placeholder for schedule
      { path: 'projects', component: Home }, // Placeholder for projects
      { path: 'reports', component: Home }, // Placeholder for reports
      { path: 'notes', component: Home }, // Placeholder for notes
      { path: 'job', component: Home }, // Placeholder for job
      { path: 'hiring', component: Home }, // Placeholder for hiring
      { path: 'help', component: Home }, // Placeholder for help
      { path: 'feedback', component: Home }, // Placeholder for feedback
      { path: 'settings', component: Home } // Placeholder for settings
    ]
  },
  { path: '**', redirectTo: '/login' }
];
